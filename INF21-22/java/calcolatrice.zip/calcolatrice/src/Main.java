public class Main {
    public static void main(String[] args) {
        CalcolatriceScientifica calc = new CalcolatriceScientifica();
        System.out.println(calc.potenza(3,3));
    }
}
