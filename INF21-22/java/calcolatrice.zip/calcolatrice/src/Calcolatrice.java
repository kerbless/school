public class Calcolatrice {
    public float somma(float a, float b) {
        return a + b;
    }
    public float sottrazione(float a, float b) {
        return a - b;
    }
    public float moltiplicazione(float a, float b) {
        return a * b;
    }
    public float divisione(float a, float b) {
        return a / b;
    }
}
